import streamlit as st
import base64
from PIL import Image
from predict_price import load_data_and_model, predict

# Load background image
background_image = Image.open('bck.jpg')

# Display background image
bg_ext = 'jpg'
bg_img = open('bck1.jpg', 'rb').read()
bg_img_b64 = base64.b64encode(bg_img).decode()

st.markdown(f"""
<style>
.stApp {{
    background-image: url(data:image/{bg_ext};base64,{bg_img_b64});
    background-size: cover;
    
}}
.stApp title {{
    color: black !important;
    font-size: 40px;
    line-height: 1;
    margin-bottom: 0.5rem;
}}
.stApp h1, .stApp h2, .stApp h3, .stApp h4, .stApp h5, .stApp h6 {{
    color: black !important;
}}
</style>
""", unsafe_allow_html=True)

# Title
st.title("House Price Prediction Using ML and RandomForestRegressor Algorithm")

# Select City
st.subheader("Select City")
selected_city = st.selectbox( "",['Mumbai', 'Bangalore'], key="city_selector")

if selected_city:
    # Load data and model
    data, model, x = load_data_and_model(selected_city)

    # Select Location
    st.subheader("Select Location")
    location_options = sorted(data['Location'].unique())
    location = st.selectbox("", location_options, key="location_selector")

    # House Details
    st.subheader("House Details")
    col1, col2 = st.columns(2)
    with col1:
        area = st.number_input("Area (in sq.ft)", min_value=0.0, value=0.0, step=100.0, key="area_input", help="Enter the area in square feet.")
    with col2:
        bhk = st.number_input("No. of Bedrooms", min_value=0, value=0, step=1, key="bhk_input", help="Enter the number of bedrooms.")

    # Additional Amenities
    st.subheader("Additional Amenities")
    col1, col2, col3 = st.columns(3)
    with col1:
        ne = st.checkbox("New/Resale", key="ne_checkbox")
    with col2:
        gy = st.checkbox("Gymnasium", key="gy_checkbox")
    with col3:
        ind = st.checkbox("Indoor Games", key="ind_checkbox")
    col1, col2, col3 = st.columns(3)
    with col1:
        ca = st.checkbox("Car Parking", key="ca_checkbox")
    with col2:
        jog = st.checkbox("Jogging Track", key="jog_checkbox")

    # Predict Price Button
    if st.button("Predict Price", key="predict_price_button"):
        try:
            price = predict(selected_city, location, area, bhk, ne, gy, ind, ca, jog)
            st.success(f"The estimated price for the selected house is: ₹ {price:,.2f}")
        except Exception as e:
            st.error("An error occurred during prediction. Please try again.")
            st.error(str(e))